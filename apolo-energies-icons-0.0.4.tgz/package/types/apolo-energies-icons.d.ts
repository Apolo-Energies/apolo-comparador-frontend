import * as _angular_core from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';
import * as _apolo_energies_icons from '@apolo-energies/icons';

interface ApoloIconDefinition {
    viewBox: string;
    content: string;
}

declare class SvgIcon {
    readonly icon: _angular_core.InputSignal<ApoloIconDefinition>;
    readonly size: _angular_core.InputSignal<number>;
    readonly cssClass: _angular_core.InputSignal<string>;
    readonly strokeWidth: _angular_core.InputSignal<number>;
    private readonly sanitizer;
    readonly svg: _angular_core.Signal<SafeHtml>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SvgIcon, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SvgIcon, "lib-svg-icon", never, { "icon": { "alias": "icon"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "cssClass": { "alias": "cssClass"; "required": false; "isSignal": true; }; "strokeWidth": { "alias": "strokeWidth"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type UiIconSource = {
    type: 'apolo';
    icon: ApoloIconDefinition;
    className?: string;
    size?: number;
    strokeWidth?: number;
} | {
    type: 'prime';
    iconClass: string;
    className?: string;
} | {
    type: 'emoji';
    value: string;
    className?: string;
};

declare class ApoloIcons {
    readonly icon: _angular_core.InputSignal<UiIconSource>;
    readonly apoloIcon: _angular_core.Signal<{
        type: "apolo";
        icon: _apolo_energies_icons.ApoloIconDefinition;
        className?: string;
        size?: number;
        strokeWidth?: number;
    } | null>;
    readonly primeIcon: _angular_core.Signal<{
        type: "prime";
        iconClass: string;
        className?: string;
    } | null>;
    readonly emojiIcon: _angular_core.Signal<{
        type: "emoji";
        value: string;
        className?: string;
    } | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ApoloIcons, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ApoloIcons, "lib-apolo-icons", never, { "icon": { "alias": "icon"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const ArrowDownBoxIcon: ApoloIconDefinition;

declare const ArrowUpDownIcon: ApoloIconDefinition;

declare const ArrowIcon: ApoloIconDefinition;

declare const CircleIcon: ApoloIconDefinition;

declare const CompassIcon: ApoloIconDefinition;

declare const DateIcon: ApoloIconDefinition;

declare const Download2Icon: ApoloIconDefinition;

declare const DownloadIcon: ApoloIconDefinition;

declare const EmailIcon: ApoloIconDefinition;

declare const filterIcon: ApoloIconDefinition;

declare const HomeIcon: ApoloIconDefinition;

declare const InfoIcon: ApoloIconDefinition;

declare const LightningIcon: ApoloIconDefinition;

declare const ListIcon: ApoloIconDefinition;

declare const LogoutIcon: ApoloIconDefinition;

declare const NoteIcon: ApoloIconDefinition;

declare const PieIcon: ApoloIconDefinition;

declare const SearchIcon: ApoloIconDefinition;

declare const SettingsIcon: ApoloIconDefinition;

declare const ShieldCheckIcon: ApoloIconDefinition;

declare const StarIcon: ApoloIconDefinition;

declare const SupportIcon: ApoloIconDefinition;

declare const TradingDownIcon: ApoloIconDefinition;

declare const TradingUpIcon: ApoloIconDefinition;

declare const UploadIcon: ApoloIconDefinition;

declare const XIcon: ApoloIconDefinition;

declare const UserIcon: ApoloIconDefinition;

declare const UserSimpleIcon: ApoloIconDefinition;

declare const UserCircleIcon: ApoloIconDefinition;

declare const chevronDownIcon: ApoloIconDefinition;

declare const chevronRightIcon: ApoloIconDefinition;

declare const MenuIcon: ApoloIconDefinition;

declare const FileSpreadsheetIcon: ApoloIconDefinition;

declare const FileDownIcon: ApoloIconDefinition;

export { ApoloIcons, ArrowDownBoxIcon, ArrowIcon, ArrowUpDownIcon, CircleIcon, CompassIcon, DateIcon, Download2Icon, DownloadIcon, EmailIcon, FileDownIcon, FileSpreadsheetIcon, HomeIcon, InfoIcon, LightningIcon, ListIcon, LogoutIcon, MenuIcon, NoteIcon, PieIcon, SearchIcon, SettingsIcon, ShieldCheckIcon, StarIcon, SupportIcon, SvgIcon, TradingDownIcon, TradingUpIcon, UploadIcon, UserCircleIcon, UserIcon, UserSimpleIcon, XIcon, chevronDownIcon, chevronRightIcon, filterIcon };
export type { ApoloIconDefinition, UiIconSource };
