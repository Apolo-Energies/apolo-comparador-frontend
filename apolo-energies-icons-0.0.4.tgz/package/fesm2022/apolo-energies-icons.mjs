import * as i0 from '@angular/core';
import { input, inject, computed, ChangeDetectionStrategy, Component } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

class SvgIcon {
    icon = input.required(...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    size = input(20, ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    cssClass = input('', ...(ngDevMode ? [{ debugName: "cssClass" }] : /* istanbul ignore next */ []));
    strokeWidth = input(1.5, ...(ngDevMode ? [{ debugName: "strokeWidth" }] : /* istanbul ignore next */ []));
    sanitizer = inject(DomSanitizer);
    svg = computed(() => {
        const icon = this.icon();
        const html = `<svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="${icon.viewBox}"
      width="${this.size()}"
      height="${this.size()}"
      fill="none"
      stroke="currentColor"
      stroke-width="${this.strokeWidth()}"
      stroke-linecap="round"
      stroke-linejoin="round"
      class="${this.cssClass()}"
      aria-hidden="true"
    >${icon.content}</svg>`;
        return this.sanitizer.bypassSecurityTrustHtml(html);
    }, ...(ngDevMode ? [{ debugName: "svg" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.5", ngImport: i0, type: SvgIcon, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.5", type: SvgIcon, isStandalone: true, selector: "lib-svg-icon", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: true, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, cssClass: { classPropertyName: "cssClass", publicName: "cssClass", isSignal: true, isRequired: false, transformFunction: null }, strokeWidth: { classPropertyName: "strokeWidth", publicName: "strokeWidth", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<span class=\"inline-flex shrink-0 items-center justify-center\" [style.width.px]=\"size()\" [style.height.px]=\"size()\"\n  [innerHTML]=\"svg()\"></span>\n", styles: [":host{display:contents}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.5", ngImport: i0, type: SvgIcon, decorators: [{
            type: Component,
            args: [{ selector: 'lib-svg-icon', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<span class=\"inline-flex shrink-0 items-center justify-center\" [style.width.px]=\"size()\" [style.height.px]=\"size()\"\n  [innerHTML]=\"svg()\"></span>\n", styles: [":host{display:contents}\n"] }]
        }], propDecorators: { icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: true }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], cssClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "cssClass", required: false }] }], strokeWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "strokeWidth", required: false }] }] } });

class ApoloIcons {
    icon = input.required(...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    apoloIcon = computed(() => {
        const value = this.icon();
        return value.type === 'apolo' ? value : null;
    }, ...(ngDevMode ? [{ debugName: "apoloIcon" }] : /* istanbul ignore next */ []));
    primeIcon = computed(() => {
        const value = this.icon();
        return value.type === 'prime' ? value : null;
    }, ...(ngDevMode ? [{ debugName: "primeIcon" }] : /* istanbul ignore next */ []));
    emojiIcon = computed(() => {
        const value = this.icon();
        return value.type === 'emoji' ? value : null;
    }, ...(ngDevMode ? [{ debugName: "emojiIcon" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.5", ngImport: i0, type: ApoloIcons, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.5", type: ApoloIcons, isStandalone: true, selector: "lib-apolo-icons", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "@if (apoloIcon(); as apolo) {\n  <lib-svg-icon\n    [icon]=\"apolo.icon\"\n    [size]=\"apolo.size ?? 20\"\n    [strokeWidth]=\"apolo.strokeWidth ?? 1.5\"\n    [cssClass]=\"apolo.className ?? ''\"\n  />\n}\n\n@if (primeIcon(); as prime) {\n  <i [class]=\"prime.iconClass + ' ' + (prime.className ?? '')\"></i>\n}\n\n@if (emojiIcon(); as emoji) {\n  <span [class]=\"emoji.className ?? ''\">{{ emoji.value }}</span>\n}\n", styles: [":host{display:contents}\n"], dependencies: [{ kind: "component", type: SvgIcon, selector: "lib-svg-icon", inputs: ["icon", "size", "cssClass", "strokeWidth"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.5", ngImport: i0, type: ApoloIcons, decorators: [{
            type: Component,
            args: [{ selector: 'lib-apolo-icons', standalone: true, imports: [SvgIcon], changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (apoloIcon(); as apolo) {\n  <lib-svg-icon\n    [icon]=\"apolo.icon\"\n    [size]=\"apolo.size ?? 20\"\n    [strokeWidth]=\"apolo.strokeWidth ?? 1.5\"\n    [cssClass]=\"apolo.className ?? ''\"\n  />\n}\n\n@if (primeIcon(); as prime) {\n  <i [class]=\"prime.iconClass + ' ' + (prime.className ?? '')\"></i>\n}\n\n@if (emojiIcon(); as emoji) {\n  <span [class]=\"emoji.className ?? ''\">{{ emoji.value }}</span>\n}\n", styles: [":host{display:contents}\n"] }]
        }], propDecorators: { icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: true }] }] } });

const ArrowDownBoxIcon = {
    viewBox: "0 0 24 24",
    content: `
    <path
      d="M9 21.9999H15C20 21.9999 22 19.9999 22 14.9999V8.99991C22 3.99991 20 1.99991 15 1.99991H9C4 1.99991 2 3.99991 2 8.99991V14.9999C2 19.9999 4 21.9999 9 21.9999Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M8.46973 10.6404L11.9997 14.1603L15.5297 10.6404"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  `,
};

const ArrowUpDownIcon = {
    viewBox: '0 0 24 24',
    content: `
    <path
            d="M14.2168 12.5127C14.6055 12.5126 14.9588 12.7377 15.123 13.0898C15.2872 13.4421 15.2332 13.8576 14.9834 14.1553L12.875 16.667C12.6851 16.8934 12.4049 17.0243 12.1094 17.0244C11.8138 17.0244 11.5328 16.8934 11.3428 16.667L9.23438 14.1553C8.98454 13.8575 8.92961 13.4421 9.09375 13.0898C9.25799 12.7377 9.61135 12.5117 10 12.5117L14.2168 12.5127ZM12.1084 6C12.4039 6.00011 12.6841 6.13108 12.874 6.35742L14.9834 8.86914C15.2331 9.16696 15.2872 9.58236 15.123 9.93457C14.9588 10.2867 14.6055 10.5127 14.2168 10.5127L10 10.5117C9.61135 10.5118 9.25799 10.2867 9.09375 9.93457C8.9296 9.58231 8.98454 9.16682 9.23438 8.86914L11.3418 6.35742C11.5318 6.13098 11.8128 6 12.1084 6Z"
            fill="currentColor"
        />
  `,
};

const ArrowIcon = {
    viewBox: '0 0 24 24',
    content: `
     <path
            d="M0.75 5.75H12.4167M12.4167 5.75L7.41667 0.75M12.4167 5.75L7.41667 10.75"
            stroke={color}
            stroke-width={1.5}
            stroke-linecap="round"
            stroke-linejoin="round"
        />
  `,
};

const CircleIcon = {
    viewBox: '0 0 24 24',
    content: `
    <path
            d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
  `,
};

const CompassIcon = {
    viewBox: "0 0 20 20",
    content: `
    <path
      d="M0.75 9.75C0.75 14.7206 4.77944 18.75 9.75 18.75C14.7206 18.75 18.75 14.7206 18.75 9.75C18.75 4.77944 14.7206 0.75 9.75 0.75C4.77944 0.75 0.75 4.77944 0.75 9.75Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M8.25 8.25L13.75 5.75L11.25 11.25L5.75 13.75L8.25 8.25Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  `,
};

const DateIcon = {
    viewBox: '0 0 20 20',
    content: `
    <path
            d="M3.3335 6.6665H16.6668M3.3335 6.6665V14C3.3335 14.9334 3.3335 15.3999 3.51515 15.7564C3.67494 16.07 3.92972 16.3252 4.24333 16.485C4.5995 16.6665 5.06599 16.6665 5.99759 16.6665H14.0027C14.9343 16.6665 15.4002 16.6665 15.7563 16.485C16.0699 16.3252 16.3256 16.07 16.4854 15.7564C16.6668 15.4002 16.6668 14.9344 16.6668 14.0028V6.6665M3.3335 6.6665V6C3.3335 5.06658 3.3335 4.59952 3.51515 4.243C3.67494 3.9294 3.92972 3.67462 4.24333 3.51483C4.59985 3.33317 5.0669 3.33317 6.00033 3.33317H6.66683M16.6668 6.6665V5.99726C16.6668 5.06567 16.6668 4.59917 16.4854 4.243C16.3256 3.9294 16.0699 3.67462 15.7563 3.51483C15.3998 3.33317 14.9337 3.33317 14.0003 3.33317H13.3335M13.3335 1.6665V3.33317M13.3335 3.33317H6.66683M6.66683 1.6665V3.33317"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
  `,
};

const Download2Icon = {
    viewBox: '0 0 24 24',
    content: `
    <path
            d="M7.76672 9.73364L9.90006 11.867L12.0334 9.73364"
            stroke="currentColor"
            stroke-width="1.5"
            strokeMiterlimit="10"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M9.90002 3.3335V11.8085"
            stroke="currentColor"
            stroke-width="1.5"
            strokeMiterlimit="10"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M16.6667 10.1504C16.6667 13.8337 14.1667 16.8171 10 16.8171C5.83337 16.8171 3.33337 13.8337 3.33337 10.1504"
            stroke="currentColor"
            stroke-width="1.5"
            strokeMiterlimit="10"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
  `,
};

const DownloadIcon = {
    viewBox: '0 0 20 20',
    content: `
    <path
            d="M13.6997 7.4165C16.6997 7.67484 17.9247 9.2165 17.9247 12.5915V12.6998C17.9247 16.4248 16.4331 17.9165 12.7081 17.9165H7.28307C3.55807 17.9165 2.06641 16.4248 2.06641 12.6998V12.5915C2.06641 9.2415 3.27474 7.69984 6.22474 7.42484"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M10 1.6665V12.3998"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M12.7918 10.5417L10.0002 13.3334L7.2085 10.5417"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
  `,
};

const EmailIcon = {
    viewBox: '0 0 20 20',
    content: `
    <path
            d="M14.1665 17.0834H5.83317C3.33317 17.0834 1.6665 15.8334 1.6665 12.9167V7.08341C1.6665 4.16675 3.33317 2.91675 5.83317 2.91675H14.1665C16.6665 2.91675 18.3332 4.16675 18.3332 7.08341V12.9167C18.3332 15.8334 16.6665 17.0834 14.1665 17.0834Z"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-miterlimit="10"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M14.1668 7.5L11.5585 9.58333C10.7002 10.2667 9.29183 10.2667 8.43349 9.58333L5.8335 7.5"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-miterlimit="10"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
  `,
};

const filterIcon = {
    viewBox: '0 0 20 20',
    content: `
    <path
      d="M18.0251 12.2916C18.0251 13.0333 17.8167 13.7333 17.4501 14.3333C16.7667 15.4833 15.5084 16.2499 14.0667 16.2499C12.6251 16.2499 11.3667 15.4749 10.6834 14.3333C10.3167 13.7416 10.1084 13.0333 10.1084 12.2916C10.1084 10.1083 11.8834 8.33325 14.0667 8.33325C16.2501 8.33325 18.0251 10.1083 18.0251 12.2916Z"
      stroke="currentColor"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M15.5501 12.2749H12.5918"
      stroke="currentColor"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M14.0669 10.833V13.7913"
      stroke="currentColor"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M17.2416 3.34985V5.19983C17.2416 5.87483 16.8166 6.71651 16.4 7.14151L14.9333 8.43317C14.6583 8.3665 14.3666 8.33317 14.0666 8.33317C11.8833 8.33317 10.1083 10.1082 10.1083 12.2915C10.1083 13.0332 10.3166 13.7332 10.6833 14.3332C10.9916 14.8498 11.4166 15.2915 11.9333 15.6082V15.8915C11.9333 16.3998 11.6 17.0748 11.175 17.3248L9.99997 18.0832C8.9083 18.7582 7.39163 17.9998 7.39163 16.6498V12.1915C7.39163 11.5998 7.04997 10.8415 6.71663 10.4248L3.51663 7.05815C3.09997 6.63315 2.7583 5.87485 2.7583 5.37485V3.43317C2.7583 2.42483 3.51663 1.6665 4.44163 1.6665H15.5583C16.4833 1.6665 17.2416 2.42485 17.2416 3.34985Z"
      stroke="currentColor"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  `,
};

const HomeIcon = {
    viewBox: '0 0 24 24',
    content: `
    <path
            d="M9.02 2.84011L3.63 7.04011C2.73 7.74011 2 9.23011 2 10.3601V17.7701C2 20.0901 3.89 21.9901 6.21 21.9901H17.79C20.11 21.9901 22 20.0901 22 17.7801V10.5001C22 9.29011 21.19 7.74011 20.2 7.05011L14.02 2.72011C12.62 1.74011 10.37 1.79011 9.02 2.84011Z"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M12 15.9999C13.6569 15.9999 15 14.6567 15 12.9999C15 11.343 13.6569 9.99986 12 9.99986C10.3431 9.99986 9 11.343 9 12.9999C9 14.6567 10.3431 15.9999 12 15.9999Z"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
  `,
};

const InfoIcon = {
    viewBox: '0 0 18 18',
    content: `
    <path
      d="M9.58333 8.125C9.58333 7.77982 9.30351 7.5 8.95833 7.5C8.61316 7.5 8.33333 7.77982 8.33333 8.125V13.125C8.33333 13.4702 8.61316 13.75 8.95833 13.75C9.30351 13.75 9.58333 13.4702 9.58333 13.125V8.125Z"
      fill="currentColor"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M8.95833 0C4.01078 0 0 4.01078 0 8.95833C0 13.9059 4.01078 17.9167 8.95833 17.9167C13.9059 17.9167 17.9167 13.9059 17.9167 8.95833C17.9167 4.01078 13.9059 0 8.95833 0ZM1.25 8.95833C1.25 4.70114 4.70114 1.25 8.95833 1.25C13.2155 1.25 16.6667 4.70114 16.6667 8.95833C16.6667 13.2155 13.2155 16.6667 8.95833 16.6667C4.70114 16.6667 1.25 13.2155 1.25 8.95833Z"
      fill="currentColor"
    />
    <path
      d="M9.79166 5.625C9.79166 6.08524 9.41857 6.45833 8.95833 6.45833C8.49809 6.45833 8.125 6.08524 8.125 5.625C8.125 5.16476 8.49809 4.79167 8.95833 4.79167C9.41857 4.79167 9.79166 5.16476 9.79166 5.625Z"
      fill="currentColor"
    />
  `,
};

const LightningIcon = {
    viewBox: '0 0 40 41',
    content: `
     <g filter="url(#lightning_shadow)">
            <rect
                x="2.5"
                y="2.5"
                width="35"
                height="35"
                rx="7.5"
                fill="#17181A"
            />
            <rect
                x="2.5"
                y="2.5"
                width="35"
                height="35"
                rx="7.5"
                stroke="#34383E"
            />
            <path
                d="M15.0749 21.0667H17.6499V27.0667C17.6499 28.4667 18.4083 28.7501 19.3333 27.7001L25.6416 20.5334C26.4166 19.6584 26.0916 18.9334 24.9166 18.9334H22.3416V12.9334C22.3416 11.5334 21.5833 11.2501 20.6583 12.3001L14.3499 19.4667C13.5833 20.3501 13.9083 21.0667 15.0749 21.0667Z"
                stroke="white"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
            />
        </g>

        <defs>
            <filter
                id="lightning_shadow"
                x="0"
                y="1"
                width="40"
                height="40"
                filterUnits="userSpaceOnUse"
                colorInterpolationFilters="sRGB"
            >
                <feFlood floodOpacity="0" />
                <feColorMatrix
                    in="SourceAlpha"
                    type="matrix"
                    values="0 0 0 0 0
                            0 0 0 0 0
                            0 0 0 0 0
                            0 0 0 0 127 0"
                />
                <feOffset dy="1" />
                <feGaussianBlur stdDeviation="1" />
                <feColorMatrix
                    type="matrix"
                    values="0 0 0 0 0.0627451
                            0 0 0 0 0.0941176
                            0 0 0 0 0.156863
                            0 0 0 0.05 0"
                />
                <feBlend in2="BackgroundImageFix" mode="normal" />
                <feBlend in="SourceGraphic" mode="normal" />
            </filter>
        </defs>
  `,
};

const ListIcon = {
    viewBox: "0 0 24 24",
    content: `
    <path
      d="M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M15.75 9H8.25"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M15.75 15H8.25"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  `,
};

const LogoutIcon = {
    viewBox: "0 0 24 24",
    content: `
    <path
      d="M8.8999 7.56023C9.2099 3.96023 11.0599 2.49023 15.1099 2.49023H15.2399C19.7099 2.49023 21.4999 4.28023 21.4999 8.75023V15.2702C21.4999 19.7402 19.7099 21.5302 15.2399 21.5302H15.1099C11.0899 21.5302 9.2399 20.0802 8.9099 16.5402"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M15.0001 12H3.62012"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M5.85 8.6499L2.5 11.9999L5.85 15.3499"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  `,
};

const NoteIcon = {
    viewBox: '0 0 24 24',
    content: `
    <path
      d="M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M15.75 9H8.25"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M15.75 15H8.25"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  `,
};

const PieIcon = {
    viewBox: "0 0 24 24",
    content: `
    <path
      d="M18.32 12.0001C20.92 12.0001 22 11.0001 21.04 7.72006C20.39 5.51006 18.49 3.61006 16.28 2.96006C13 2.00006 12 3.08006 12 5.68006V8.56006C12 11.0001 13 12.0001 15 12.0001H18.32Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M19.9999 14.7C19.0699 19.33 14.6299 22.69 9.57993 21.87C5.78993 21.26 2.73993 18.21 2.11993 14.42C1.30993 9.39001 4.64993 4.95001 9.25993 4.01001"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  `,
};

const SearchIcon = {
    viewBox: '0 0 17 17',
    content: `
     <path
            d="M11.9526 11.9532L15.7495 15.7501M13.875 7.3125C13.875 10.9369 10.9369 13.875 7.3125 13.875C3.68813 13.875 0.75 10.9369 0.75 7.3125C0.75 3.68813 3.68813 0.75 7.3125 0.75C10.9369 0.75 13.875 3.68813 13.875 7.3125Z"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
  `,
};

const SettingsIcon = {
    viewBox: "0 0 22 21",
    content: `
    <path
      d="M19.0965 7.10066L18.7303 6.89693C18.6734 6.8653 18.6455 6.84942 18.618 6.83297C18.3449 6.66939 18.1147 6.44337 17.9468 6.17296C17.9299 6.14575 17.9139 6.11722 17.8814 6.06083C17.8488 6.00451 17.8324 5.97597 17.8172 5.94772C17.6666 5.6664 17.5851 5.35289 17.5802 5.0338C17.5797 5.00172 17.5798 4.96894 17.5809 4.90378L17.5881 4.47852C17.5995 3.79799 17.6052 3.45667 17.5096 3.15035C17.4247 2.87827 17.2825 2.62766 17.0928 2.41499C16.8782 2.17458 16.5813 2.00308 15.9868 1.6605L15.493 1.37594C14.9002 1.03431 14.6036 0.863443 14.2889 0.798302C14.0105 0.740672 13.7231 0.743343 13.4457 0.805626C13.1325 0.875922 12.8397 1.05125 12.2544 1.40169L12.2511 1.40328L11.8973 1.61514C11.8414 1.64864 11.813 1.66553 11.785 1.68112C11.5067 1.83584 11.1961 1.92139 10.8778 1.9316C10.8458 1.93263 10.8131 1.93263 10.7479 1.93263C10.6831 1.93263 10.649 1.93263 10.617 1.9316C10.2981 1.92134 9.9868 1.83533 9.70809 1.67997C9.68 1.66431 9.65222 1.64729 9.59615 1.61364L9.24008 1.39986C8.65081 1.0461 8.35573 0.868948 8.04086 0.798302C7.76229 0.7358 7.47395 0.734071 7.19449 0.792443C6.87894 0.858351 6.58235 1.03049 5.98916 1.37477L5.98653 1.37594L5.49886 1.65897L5.49347 1.66227C4.90562 2.00345 4.61099 2.17445 4.39828 2.41387C4.20952 2.62633 4.06843 2.87655 3.98398 3.14791C3.88852 3.45465 3.89361 3.7967 3.90511 4.48043L3.91226 4.90509C3.91334 4.9694 3.91522 5.00135 3.91475 5.03298C3.91002 5.35272 3.82744 5.66687 3.67633 5.94869C3.66138 5.97656 3.64528 6.00444 3.61312 6.06011C3.58094 6.11582 3.56536 6.14352 3.54867 6.17041C3.37995 6.44226 3.14872 6.6696 2.87391 6.83346C2.84673 6.84967 2.81808 6.86525 2.7618 6.89645L2.40023 7.09681C1.79867 7.43018 1.49795 7.59701 1.27914 7.83443C1.08557 8.04446 0.939334 8.29358 0.850072 8.5649C0.749171 8.8716 0.749256 9.21552 0.750818 9.90328L0.752095 10.4654C0.753646 11.1486 0.755775 11.4899 0.856902 11.7946C0.946368 12.0641 1.09153 12.3117 1.28402 12.5205C1.5016 12.7564 1.79932 12.9222 2.39633 13.2544L2.75467 13.4537C2.81565 13.4876 2.84634 13.5044 2.87575 13.5221C3.14806 13.6861 3.37747 13.9128 3.54476 14.1831C3.56284 14.2123 3.58019 14.2426 3.61488 14.3032C3.64914 14.363 3.66667 14.393 3.68252 14.423C3.82919 14.7007 3.90772 15.0092 3.91307 15.3232C3.91365 15.3571 3.91316 15.3914 3.91199 15.4604L3.90511 15.8679C3.89353 16.554 3.88849 16.8974 3.9845 17.205C4.06945 17.4771 4.21142 17.7277 4.40121 17.9404C4.61573 18.1808 4.91313 18.3522 5.50765 18.6948L6.00136 18.9793C6.59421 19.3209 6.89053 19.4916 7.20527 19.5567C7.48372 19.6144 7.77123 19.6121 8.04867 19.5498C8.36225 19.4794 8.65606 19.3035 9.24301 18.9521L9.59683 18.7402C9.65281 18.7067 9.68115 18.6899 9.7092 18.6743C9.98747 18.5196 10.2978 18.4336 10.6161 18.4234C10.6481 18.4223 10.6807 18.4223 10.746 18.4223C10.8114 18.4223 10.844 18.4223 10.8761 18.4234C11.195 18.4336 11.5073 18.5199 11.786 18.6753C11.8105 18.6889 11.8351 18.7037 11.8782 18.7296L12.2544 18.9554C12.8437 19.3092 13.1382 19.4859 13.453 19.5565C13.7316 19.619 14.0202 19.6216 14.2996 19.5632C14.6151 19.4973 14.9123 19.3248 15.5051 18.9807L16.0001 18.6934C16.5884 18.3521 16.8833 18.1809 17.0961 17.9414C17.2849 17.7289 17.4261 17.4788 17.5106 17.2074C17.6053 16.9029 17.5996 16.5635 17.5883 15.8896L17.5809 15.4502C17.5798 15.3858 17.5797 15.3539 17.5802 15.3222C17.5849 15.0025 17.6661 14.6881 17.8172 14.4063C17.8321 14.3785 17.8484 14.3504 17.8804 14.2949C17.9126 14.2392 17.9293 14.2114 17.9459 14.1845C18.1147 13.9127 18.3461 13.6851 18.6209 13.5213C18.6478 13.5053 18.6754 13.49 18.7304 13.4595L18.7323 13.4586L19.0938 13.2583C19.6954 12.9249 19.9967 12.7579 20.2155 12.5205C20.4091 12.3104 20.5551 12.0617 20.6444 11.7903C20.7447 11.4854 20.7439 11.1435 20.7424 10.4638L20.7411 9.88961C20.7395 9.20644 20.7387 8.86513 20.6375 8.56051C20.5481 8.29101 20.4021 8.04334 20.2096 7.83458C19.9922 7.59884 19.6941 7.43299 19.0983 7.10151L19.0965 7.10066Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M6.74691 10.1777C6.74691 12.3868 8.53777 14.1777 10.7469 14.1777C12.9561 14.1777 14.7469 12.3868 14.7469 10.1777C14.7469 7.96856 12.9561 6.1777 10.7469 6.1777C8.53777 6.1777 6.74691 7.96856 6.74691 10.1777Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  `,
};

const ShieldCheckIcon = {
    viewBox: '0 0 24 24',
    content: `
      <path
            d="M8.7418 1.8583L4.58346 3.42497C3.62513 3.7833 2.8418 4.91663 2.8418 5.9333V12.125C2.8418 13.1083 3.4918 14.4 4.28346 14.9916L7.8668 17.6666C9.0418 18.55 10.9751 18.55 12.1501 17.6666L15.7335 14.9916C16.5251 14.4 17.1751 13.1083 17.1751 12.125V5.9333C17.1751 4.9083 16.3918 3.77497 15.4335 3.41663L11.2751 1.8583C10.5668 1.59997 9.43346 1.59997 8.7418 1.8583Z"
            stroke={color}
            stroke-width={1.5}
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M7.5415 9.89157L8.88317 11.2332L12.4665 7.6499"
            stroke={color}
            stroke-width={1.5}
            stroke-linecap="round"
            stroke-linejoin="round"
        />
  `,
};

const StarIcon = {
    viewBox: '0 0 20 21',
    content: `
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M14.4676 0.316193L13.1149 3.00528C13.0619 3.11188 12.9772 3.19951 12.8725 3.25615L10.2561 4.64704C10.0661 4.75102 9.94786 4.9504 9.94786 5.16705C9.94786 5.38371 10.0661 5.58309 10.2561 5.68707L12.8725 7.07737C12.9774 7.13408 13.0621 7.22193 13.1149 7.32887L14.4676 10.018C14.562 10.2114 14.7584 10.3342 14.9737 10.3342C15.1889 10.3342 15.3854 10.2114 15.4797 10.018L16.8331 7.32887C16.8859 7.22197 16.9706 7.13411 17.0755 7.07737L19.6918 5.68707C19.8815 5.58279 19.9994 5.38352 19.9994 5.16705C19.9994 4.95058 19.8815 4.75131 19.6918 4.64704L17.0755 3.25615C16.9707 3.19951 16.8861 3.11188 16.8331 3.00524L15.4797 0.316154C15.3854 0.122692 15.1889 -8.01086e-05 14.9737 -8.01086e-05C14.7584 -8.01086e-05 14.562 0.122692 14.4676 0.316154L14.4676 0.316193ZM5.61927 8.15798L3.93807 11.4998C3.87182 11.6328 3.76595 11.7421 3.63504 11.8125L0.382933 13.5404C0.14681 13.6697 0 13.9175 0 14.1867C0 14.456 0.146807 14.7038 0.382933 14.8331L3.63504 16.561C3.76595 16.6314 3.87182 16.7406 3.93807 16.8737L5.61927 20.2149C5.73628 20.4557 5.98057 20.6086 6.24836 20.6086C6.51615 20.6086 6.76043 20.4557 6.87745 20.2149L8.55926 16.8737C8.62533 16.7405 8.73125 16.6312 8.86228 16.561L12.1138 14.8331C12.3499 14.7038 12.4967 14.456 12.4967 14.1867C12.4967 13.9175 12.3499 13.6697 12.1138 13.5404L8.86167 11.8143C8.73064 11.7441 8.62472 11.6347 8.55865 11.5016L6.87683 8.1598C6.75949 7.91932 6.51532 7.76677 6.24775 7.76677C5.98017 7.76677 5.73601 7.91932 5.61866 8.1598L5.61927 8.15798Z"
      fill="currentColor"
    />
  `,
};

const SupportIcon = {
    viewBox: "0 0 20 20",
    content: `
    <path
      d="M6.89648 6.82361C7.06728 6.29732 7.38015 5.82896 7.80078 5.46948C8.22141 5.11001 8.7338 4.87378 9.28027 4.78708C9.82675 4.70038 10.3862 4.7664 10.8975 4.97803C11.4087 5.18966 11.8514 5.53875 12.1768 5.98633C12.5021 6.43391 12.6969 6.96256 12.7404 7.51416C12.7839 8.06576 12.6738 8.61879 12.4227 9.11182C12.1715 9.60484 11.7894 10.0185 11.3176 10.3076C10.8458 10.5967 10.3033 10.7498 9.75 10.7498V11.7502M9.75 18.75C4.77944 18.75 0.75 14.7206 0.75 9.75C0.75 4.77944 4.77944 0.75 9.75 0.75C14.7206 0.75 18.75 4.77944 18.75 9.75C18.75 14.7206 14.7206 18.75 9.75 18.75ZM9.7998 14.75V14.85L9.7002 14.8502V14.75H9.7998Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  `,
};

const TradingDownIcon = {
    viewBox: '0 0 24 24',
    content: `
    <path
      d="M9.5 8.16667L6.7 5.36667L5.63333 6.96667L3.5 4.83333M9.5 8.16667L8.16667 8.16667M9.5 8.16667L9.5 6.83333M12.5 6.5C12.5 9.81371 9.81371 12.5 6.5 12.5C3.18629 12.5 0.5 9.81371 0.499999 6.5C0.499999 3.18629 3.18629 0.499999 6.5 0.499999C9.81371 0.499999 12.5 3.18629 12.5 6.5Z"
      stroke={color}
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  `,
};

const TradingUpIcon = {
    viewBox: '0 0 24 24',
    content: `
    <path
            d="M11 6.33352L8.2 9.13352L7.13333 7.53352L5 9.66685"
            stroke={color}
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M11 6.33352H9.66667"
            stroke={color}
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M11 6.33352V7.66685"
            stroke={color}
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M14 8.00018C14 4.68647 11.3137 2.00018 8 2.00018C4.68629 2.00018 2 4.68647 2 8.00018C2 11.3139 4.68629 14.0002 8 14.0002C11.3137 14.0002 14 11.3139 14 8.00018Z"
            stroke={color}
            stroke-linecap="round"
            stroke-linejoin="round"
        />
  `,
};

const UploadIcon = {
    viewBox: '0 0 38 38',
    content: `
    <path
      d="M26.0301 14.0916C31.7301 14.5824 34.0576 17.5116 34.0576 23.9241V24.1299C34.0576 31.2074 31.2234 34.0416 24.1459 34.0416H13.8384C6.76092 34.0416 3.92676 31.2074 3.92676 24.1299V23.9241C3.92676 17.5591 6.22259 14.6299 11.8276 14.1074"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M19 23.75V5.73169"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M24.3041 9.26242L19 3.95825L13.6958 9.26242"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  `,
};

const XIcon = {
    viewBox: '0 0 24 24',
    content: `
    <line x1="18" y1="6" x2="6" y2="18" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
    <line x1="6" y1="6" x2="18" y2="18" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
  `,
};

const UserIcon = {
    viewBox: '0 0 20 20',
    content: `
    <path
            d="M10.0999 10.6501C10.0416 10.6418 9.9666 10.6418 9.89993 10.6501C8.43327 10.6001 7.2666 9.40009 7.2666 7.92509C7.2666 6.41676 8.48327 5.19176 9.99993 5.19176C11.5083 5.19176 12.7333 6.41676 12.7333 7.92509C12.7249 9.40009 11.5666 10.6001 10.0999 10.6501Z"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M15.6166 16.1501C14.1333 17.5085 12.1666 18.3335 9.99997 18.3335C7.8333 18.3335 5.86663 17.5085 4.3833 16.1501C4.46663 15.3668 4.96663 14.6001 5.8583 14.0001C8.14163 12.4835 11.875 12.4835 14.1416 14.0001C15.0333 14.6001 15.5333 15.3668 15.6166 16.1501Z"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M9.99984 18.3335C14.6022 18.3335 18.3332 14.6026 18.3332 10.0002C18.3332 5.39781 14.6022 1.66685 9.99984 1.66685C5.39746 1.66685 1.6665 5.39781 1.6665 10.0002C1.6665 14.6026 5.39746 18.3335 9.99984 18.3335Z"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
  `,
};

const UserSimpleIcon = {
    viewBox: '0 0 24 24',
    content: `
    <path
      d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"
      stroke="currentColor"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <circle
      cx="12"
      cy="7"
      r="4"
      stroke="currentColor"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  `,
};

const UserCircleIcon = {
    viewBox: '0 0 24 24',
    content: `
    <path
      d="M17.925 20.056a6 6 0 0 0-11.851.001"
      stroke="currentColor"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <circle
      cx="12"
      cy="11"
      r="4"
      stroke="currentColor"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <circle
      cx="12"
      cy="12"
      r="10"
      stroke="currentColor"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  `,
};

const chevronDownIcon = {
    viewBox: '0 0 24 24',
    content: `
    <path d="m6 9 6 6 6-6" />
  `,
};

const chevronRightIcon = {
    viewBox: '0 0 24 24',
    content: `
    <path d="m9 18 6-6-6-6" />
  `,
};

const MenuIcon = {
    viewBox: '0 0 24 24',
    content: `
    <path d="M4 5h16" />
    <path d="M4 12h16" />
    <path d="M4 19h16" />
  `,
};

const FileSpreadsheetIcon = {
    viewBox: '0 0 24 24',
    content: `
    <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"
      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
    <path d="M14 2v4a2 2 0 0 0 2 2h4"
      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
    <path d="M8 13h2"
      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M14 13h2"
      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M8 17h2"
      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M14 17h2"
      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  `,
};

const FileDownIcon = {
    viewBox: '0 0 24 24',
    content: `
    <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"
      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
    <path d="M14 2v4a2 2 0 0 0 2 2h4"
      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
    <path d="M12 18v-6"
      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="m9 15 3 3 3-3"
      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
  `,
};

/*
 * Public API Surface of apolo-icons
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ApoloIcons, ArrowDownBoxIcon, ArrowIcon, ArrowUpDownIcon, CircleIcon, CompassIcon, DateIcon, Download2Icon, DownloadIcon, EmailIcon, FileDownIcon, FileSpreadsheetIcon, HomeIcon, InfoIcon, LightningIcon, ListIcon, LogoutIcon, MenuIcon, NoteIcon, PieIcon, SearchIcon, SettingsIcon, ShieldCheckIcon, StarIcon, SupportIcon, SvgIcon, TradingDownIcon, TradingUpIcon, UploadIcon, UserCircleIcon, UserIcon, UserSimpleIcon, XIcon, chevronDownIcon, chevronRightIcon, filterIcon };
//# sourceMappingURL=apolo-energies-icons.mjs.map
